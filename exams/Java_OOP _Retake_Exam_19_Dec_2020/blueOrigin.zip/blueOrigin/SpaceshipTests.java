package blueOrigin;

import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class SpaceshipTests {

    @Test(expected = NullPointerException.class)
    public void testShouldThrowWhenInstantiatingWithNullName() {
        new Spaceship(null, 0);
    }

    @Test(expected = NullPointerException.class)
    public void testShouldThrowWhenPassingBlankNameToCtor() {
        new Spaceship("", 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testShouldThrowWhenPassingNegativeCapacityToCtor() {
        new Spaceship("farm", -1);
    }

    @Test
    public void testShouldSuccessfullyInitializeFarm() {
        Spaceship spaceship = new Spaceship("Denis", 5);
        assertNotNull(spaceship);
        assertEquals("Denis", spaceship.getName());
        assertEquals(5, spaceship.getCapacity());
        assertEquals(0, spaceship.getCount());
    }


    @Test(expected = IllegalArgumentException.class)
    public void testShouldThrowWhenAddingWithNoFreeSpace() {
        Spaceship spaceship = new Spaceship("Denis", 1);
        spaceship.add(new Astronaut("AS1", 5));
        spaceship.add(new Astronaut("As2", 5));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testShouldThrowWhenAddingPresentAnimal() {
        Spaceship spaceship = new Spaceship("Denis", 3);
        spaceship.add(new Astronaut("AS1", 5));
        spaceship.add(new Astronaut("AS1", 5));
    }

    @Test
    public void testShouldAddAnimalToFarm() {
        Spaceship spaceship = new Spaceship("Dneis", 2);
        assertEquals(0, spaceship.getCount());
        spaceship.add(new Astronaut("AS1", 5));
        assertEquals(1, spaceship.getCount());
    }

    @Test
    public void testShouldRemoveAnimal() {
        Spaceship spaceship = new Spaceship("Denis", 2);
        spaceship.add(new Astronaut("AS1", 5));
        spaceship.add(new Astronaut("AS2", 5));
        assertEquals(2, spaceship.getCount());
        assertTrue(spaceship.remove("AS2"));
        assertEquals(1, spaceship.getCount());
    }

}
