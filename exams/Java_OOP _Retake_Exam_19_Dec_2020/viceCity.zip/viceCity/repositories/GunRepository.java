package viceCity.repositories;

import viceCity.models.guns.Gun;
import viceCity.repositories.interfaces.Repository;

import java.util.ArrayList;
import java.util.Collection;

public class GunRepository implements Repository {
    Collection<Gun> models;

    public GunRepository() {
        models = new ArrayList<>();
    }

    @Override
    public Collection getModels() {
        return models;
    }

    @Override
    public void add(Object model) {
        if(!models.contains((Gun) model)) {
            models.add((Gun) model);
        }
    }

    @Override
    public boolean remove(Object model) {
        return models.remove((Gun) model);
    }

    @Override
    public Object find(String name) {
        return models.stream()
                .filter((g) -> {
                    return g.getName().equals(name);
                })
                .findFirst().orElse(null);
    }
}
