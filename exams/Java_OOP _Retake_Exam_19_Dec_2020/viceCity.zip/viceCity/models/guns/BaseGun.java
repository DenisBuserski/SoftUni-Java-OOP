package viceCity.models.guns;

import viceCity.common.ExceptionMessages;

public abstract class BaseGun implements Gun {
    protected int BULLETS_PER_SHOT_COUNT = 1;

    private String name;

    private int bulletsPerBarrel;
    private int bulletsInBarrel;

    private int totalBullets;

    private boolean canFire;

    public BaseGun(String name, int bulletsPerBarrel, int totalBullets) {
        setName(name);

        setBulletsPerBarrel(bulletsPerBarrel);

        setTotalBullets(totalBullets);
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new NullPointerException(ExceptionMessages.NAME_NULL);
        }

        this.name = name;
    }

    private void setBulletsPerBarrel(int bulletsPerBarrel) {
        if (bulletsPerBarrel < 0) {
            throw new IllegalArgumentException(ExceptionMessages.BULLETS_LESS_THAN_ZERO);
        }

        this.bulletsPerBarrel = bulletsPerBarrel;

        this.bulletsInBarrel = this.bulletsPerBarrel;
    }

    private void setTotalBullets(int totalBullets) {
        if(totalBullets < 0) {
            throw new IllegalArgumentException(ExceptionMessages.BULLETS_LESS_THAN_ZERO);
        }

        this.totalBullets = totalBullets;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getBulletsPerBarrel() {
        return this.bulletsPerBarrel;
    }

    @Override
    public boolean canFire() {
        if (totalBullets - 1 >= 0) {
            canFire = true;
        } else {
            canFire = false;
        }

        return this.canFire;
    }

    @Override
    public int getTotalBullets() {
        return this.totalBullets;
    }

    @Override
    public int fire() {
        if(bulletsInBarrel == 0) {
            if(bulletsPerBarrel > totalBullets) {
                bulletsInBarrel += totalBullets;

                totalBullets = 0;
            }else{
                bulletsInBarrel += bulletsPerBarrel;

                totalBullets -= bulletsPerBarrel;
            }
        }

        if(bulletsInBarrel > 0) {
            int bulletsShot = Math.min(BULLETS_PER_SHOT_COUNT, bulletsInBarrel);

            bulletsInBarrel -= bulletsShot;

            return bulletsShot;
        }

        return 0;
    }
}
