package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.Collection;
import java.util.Iterator;

public class GangNeighbourhood implements Neighbourhood {

    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        Iterator<Player> playerIterator = civilPlayers.iterator();
        if (playerIterator.hasNext()) {
            Player currCivilPlayer = playerIterator.next();

            Iterator<Gun> gunIterator = mainPlayer.getGunRepository().getModels().iterator();

            if (gunIterator.hasNext()) {
                Gun currGun = gunIterator.next();

                while (true) {
                    if (!currCivilPlayer.isAlive()) {
                        if (playerIterator.hasNext()) {
                            currCivilPlayer = playerIterator.next();
                        } else {
                            break;
                        }
                    }

                    currCivilPlayer.takeLifePoints(currGun.fire());

                    if (currCivilPlayer.isAlive() && !currGun.canFire()) {
                        if (gunIterator.hasNext()) {
                            currGun = gunIterator.next();
                        } else {
                            break;
                        }
                    }
                }
            }

            playerIterator = civilPlayers.iterator();

            if(playerIterator.hasNext()) {
                while (playerIterator.hasNext()) {
                    Player civilPlayer = playerIterator.next();

                    for (Gun gun : civilPlayer.getGunRepository().getModels()) {
                        while (gun.canFire()) {
                            mainPlayer.takeLifePoints(gun.fire());

                            if (!mainPlayer.isAlive()) {
                                break;
                            }
                        }
                    }

                    if (!mainPlayer.isAlive()) {
                        break;
                    }
                }
            }
        }
    }
}
