package christmasRaces.core;

import christmasRaces.common.ExceptionMessages;
import christmasRaces.common.OutputMessages;
import christmasRaces.core.interfaces.Controller;
import christmasRaces.entities.cars.Car;
import christmasRaces.entities.cars.MuscleCar;
import christmasRaces.entities.cars.SportsCar;
import christmasRaces.entities.drivers.Driver;
import christmasRaces.entities.drivers.DriverImpl;
import christmasRaces.entities.races.Race;
import christmasRaces.entities.races.RaceImpl;
import christmasRaces.repositories.interfaces.CarRepository;
import christmasRaces.repositories.interfaces.DriverRepository;
import christmasRaces.repositories.interfaces.RaceRepository;
import christmasRaces.repositories.interfaces.Repository;

import java.util.*;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private Repository<Car> carRepository;
    private Repository<Race> raceRepository;
    private Repository<Driver> driverRepository;


    public ControllerImpl(Repository<Driver> driverRepository, Repository<Car> carRepository, Repository<Race> raceRepository) {
        this.driverRepository = new DriverRepository();
        this.carRepository = new CarRepository();
        this.raceRepository = new RaceRepository();
    }

    @Override
    public String createDriver(String driver) {
        Driver driver2 = this.driverRepository.getByName(driver);
        if (this.driverRepository.getAll().contains(driver2)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_EXISTS, driver));
        }
        Driver driver1 = new DriverImpl(driver);
        this.driverRepository.add(driver1);
        String output = String.format(OutputMessages.DRIVER_CREATED, driver);
        return output;
    }

    @Override
    public String createCar(String type, String model, int horsePower) {
        Car car1 = this.carRepository.getByName(model);
        if (this.carRepository.getAll().contains(car1)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.CAR_EXISTS, model));
        }
        Car car;
        String output = "";

        switch (type) {
            case "Muscle":
                car = new MuscleCar(model, horsePower);
                this.carRepository.add(car);
                output = String.format(OutputMessages.CAR_CREATED, "MuscleCar", model);
                break;
            case "Sports":
                car = new SportsCar(model, horsePower);
                this.carRepository.add(car);
                output = String.format(OutputMessages.CAR_CREATED, "SportsCar", model);
                break;
        }
        return output;
    }

    @Override
    public String addCarToDriver(String driverName, String carModel) {
        Driver driver = this.driverRepository.getByName(driverName);
        Car car = this.carRepository.getByName(carModel);
        if (driver.getName().isEmpty()) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_NOT_FOUND, driverName));
        } else if (car == null || car.getModel().isEmpty()) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.CAR_NOT_FOUND, carModel));
        }
        Car car1 = this.carRepository.getByName(carModel);
        this.driverRepository.getByName(driverName).addCar(car1);
        return String.format(OutputMessages.CAR_ADDED, driverName, carModel);
    }

    @Override
    public String addDriverToRace(String raceName, String driverName) {
        Race race = this.raceRepository.getByName(raceName);
        Driver driver = this.driverRepository.getByName(driverName);
        if (race == null || race.getName().isEmpty()) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_NOT_FOUND, raceName));
        } else if (driver == null || driver.getName().isEmpty()) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.DRIVER_NOT_FOUND, driverName));
        }
        Driver driver1 = this.driverRepository.getByName(driverName);
        this.raceRepository.getByName(raceName).addDriver(driver1);
        return String.format(OutputMessages.DRIVER_ADDED, driverName, raceName);
    }








    @Override
    public String startRace(String raceName) {
        Race race = this.raceRepository.getByName(raceName);


        if (!this.raceRepository.getAll().contains(race)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_NOT_FOUND, raceName));
        }


        List<Driver> bestDrivers = this.driverRepository.getAll()
                .stream()
                .sorted((d1, d2) -> Integer.compare(d2.getNumberOfWins(), d1.getNumberOfWins()))
                .collect(Collectors.toList());

        if (bestDrivers.size() < 3) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_INVALID, raceName, 3));
        }

        Race race1 = this.raceRepository.getByName(raceName);
        this.raceRepository.remove(race1);
        Collection<Driver> all = this.driverRepository.getAll();
        List<Driver> collect = all.stream().collect(Collectors.toList());


        StringBuilder output = new StringBuilder();
        output.append(String.format("Driver %s wins %s race.", collect.get(0).getName(), raceName))
                .append(System.lineSeparator())
                .append(String.format("Driver %s is second in %s race.", collect.get(1).getName(), raceName))
                .append(System.lineSeparator())
                .append(String.format("Driver %s is third in %s race.", collect.get(2).getName(), raceName));

        return output.toString().trim();
    }

    @Override
    public String createRace(String name, int laps) {
        if (this.raceRepository.getAll().contains(name)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_EXISTS, name));
        }
        Race race = new RaceImpl(name, laps);
        this.raceRepository.add(race);
        return String.format(OutputMessages.RACE_CREATED, name);
    }
}
