package spaceStation.models.planets;

import java.util.Collection;
import java.util.List;

public interface Planet {
    List<String> getItems();

    String getName();
}
