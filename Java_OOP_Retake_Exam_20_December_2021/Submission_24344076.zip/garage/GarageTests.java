package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.Computer;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class GarageTests {
    private Garage garage;
    private Car car1;
    private Car car2;

    @Before
    public void setUp() {
        garage = new Garage();
        car1 = new Car("HP", 10, 1900);
        car2 = new Car("Mac", 10, 1750);
    }


    @Test
    public void testGetCountShouldReturnTheNumberOfCars() {
        garage.addCar(car1);
        garage.addCar(car2);
        Assert.assertEquals(2, garage.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWhenAddedCarWithNullValueFailShoutBeThrown() {
        Car car = null;
        garage.addCar(car);
    }


    @Test
    public void testAddCarThatDoesNotAppearsShouldBeAddedToGarage() {
        garage.addCar(car1);
        garage.addCar(car2);

        Assert.assertEquals(2, garage.getCount());
    }


    @Test
    public void testFindAllCarsWithMaxSpeedAbove() {
        garage.addCar(car1);
        garage.addCar(car2);
        Assert.assertEquals(0, garage.findAllCarsWithMaxSpeedAbove(1500).size());
    }


    @Test
    public void testGetHeroWithHighestLevel() {
        this.garage.addCar(car1);
        Car betterHero = new Car("PC", 11, 2000);
        this.garage.addCar(betterHero);
        Assert.assertEquals(betterHero, garage.getTheMostExpensiveCar());
    }

    @Test
    public void testGetCarsByBrandShouldReturnOnlyCarsFromThisBrand() {
        Car computerHPOne = new Car("HP", 15, 1900);
        Car computerAsus = new Car("Mac", 20, 1750);
        Car computerHPTwo = new Car("HP", 25, 1900);
        Car computerHPThree = new Car("HP", 30, 1900);

        garage.addCar(computerHPOne);
        garage.addCar(computerAsus);
        garage.addCar(computerHPTwo);
        garage.addCar(computerHPThree);

        List<Car> hpComputersList = garage.findAllCarsByBrand("HP");

        Assert.assertEquals(3, hpComputersList.size());
    }

    @Test
    public void testGetHeroesCollection() {
        this.garage.addCar(this.car1);
        this.garage.getCars()
                .stream()
                .map(h -> h.getBrand() + h.getMaxSpeed() + h.getPrice())
                .collect(Collectors.toUnmodifiableList());



    }
}