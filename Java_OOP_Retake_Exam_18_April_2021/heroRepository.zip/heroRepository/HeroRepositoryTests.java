package heroRepository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.stream.Collectors;

public class HeroRepositoryTests {
    private HeroRepository heroRepository;
    private Hero hero;

    @Before
    public void setUp() {
        this.heroRepository = new HeroRepository();
        this.hero = new Hero("Desi", 2);
    }

    // Create + Constructor + Count
    @Test(expected = NullPointerException.class) // HeroRepository.Hero == null
    public void testCreateHeroIsNull() {
        this.heroRepository.create(null);
    }

    @Test(expected = IllegalArgumentException.class) // Duplicate name
    public void testCreateHeroWithDuplicateName() {
        this.heroRepository.create(this.hero);
        this.heroRepository.create(this.hero);
    }

    @Test // Successful create hero
    public void testCreateSuccessfulHero() {
        Assert.assertEquals(0, this.heroRepository.getCount());
        this.heroRepository.create(this.hero);
        Assert.assertEquals(1, this.heroRepository.getCount());
        Hero createdHero = this.heroRepository.getHero("Desi");
        Assert.assertEquals(createdHero.getName(), this.hero.getName());
        Assert.assertEquals(createdHero.getLevel(), this.hero.getLevel());
    }

    @Test(expected = NullPointerException.class)
    public void testRemove() {
        // name is null
        this.heroRepository.create(null);
        this.heroRepository.remove(null);
    }

    @Test(expected = NullPointerException.class)
    public void testRemove2() {
        // name is empty
        this.heroRepository.create(new Hero("", 1));
        this.heroRepository.remove("");
    }

    @Test
    public void testRemove3() {
        // successfully removed
        Assert.assertEquals(0, this.heroRepository.getCount());
        this.heroRepository.create(this.hero);
        Assert.assertEquals(1, this.heroRepository.getCount());
        this.heroRepository.remove("Desi");
        Assert.assertEquals(0, this.heroRepository.getCount());
        Hero removedHero = this.heroRepository.getHero("Desi");
        Assert.assertNull(removedHero);
    }

    @Test
    public void testGetHeroWithHighestLevel() {
        this.heroRepository.create(this.hero);
        Hero betterHero = new Hero("Ivan", 5);
        this.heroRepository.create(betterHero);
        Assert.assertEquals(betterHero, heroRepository.getHeroWithHighestLevel());
    }

    @Test
    public void testGetHeroesCollection() {
        this.heroRepository.create(this.hero);
        this.heroRepository.getHeroes()
                .stream()
                .map(h -> h.getName() + h.getLevel())
                .collect(Collectors.toUnmodifiableList());



    }

}