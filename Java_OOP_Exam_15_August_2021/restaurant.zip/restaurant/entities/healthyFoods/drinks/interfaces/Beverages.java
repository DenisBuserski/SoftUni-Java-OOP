package restaurant.entities.healthyFoods.drinks.interfaces;

public interface Beverages {
    String getName();

    int getCounter();

    double getPrice();

    String getBrand();
}
