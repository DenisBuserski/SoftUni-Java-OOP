package CounterStriker.models.guns;

public class Pistol extends GunImpl {
    private static final int BULLETS_FIRED = 1;

    public Pistol(String name, int bulletsCount) {
        super(name, bulletsCount);
    }

    @Override
    public int fire() {
        if (this.getBulletsCount() - BULLETS_FIRED < 0) {
            return 0;
        }
        this.setBulletsCount(this.getBulletsCount() - BULLETS_FIRED);
        return BULLETS_FIRED;
    }
}
